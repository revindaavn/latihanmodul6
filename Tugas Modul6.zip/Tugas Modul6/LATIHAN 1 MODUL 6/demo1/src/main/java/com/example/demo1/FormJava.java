package com.example.demo1;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;

public class FormJava extends Application {
    @Override
    public void start(Stage primaryStage) throws IOException {
        primaryStage.setTitle("Form Login");

        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10); //menetapkan spasi horizontal
        grid.setVgap(10); //menetapkan spasi vertikal
        grid.setPadding(new Insets(25,25,25,25));

        Scene scene = new Scene (grid, 300, 275); //membuat grid 300 x 275 pixel
        primaryStage.setScene(scene);

        Text sceneTitle = new Text("Welcome!!");
        sceneTitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        grid.add(sceneTitle, 0,0,2,1); //baris 0, kolom 0, lebar 2, tinggi 1

        Label username = new Label("User Name :");
        grid.add(username, 0, 1); //kolom 0, baris 1

        TextField userTextField = new TextField();
        grid.add(userTextField, 1, 1);

        Label pw = new Label("Password : ");
        grid.add(pw, 0, 2);

        PasswordField pwBox = new PasswordField();
        grid.add(pwBox, 1, 2);

        Button btn = new Button("Sign in!"); //menambah tombol eskeskusi
        HBox hbBtn = new HBox(10); //spasi 10
        hbBtn.setAlignment(Pos. BOTTOM_RIGHT); //posisi horizontal ke kanan bawah
        hbBtn.getChildren().add(btn);
        grid.add(hbBtn, 1, 4);

        final Text actionTarget = new Text();
        grid.add(actionTarget, 1, 6);

        btn.setOnAction(new EventHandler<ActionEvent>() { //perintah tombol sig in ditekan
            @Override
            public void handle(ActionEvent actionEvent) {
                actionTarget.setFill(Color.FIREBRICK);
                actionTarget.setText("Sign in button pressed!");
            }
        });

        primaryStage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}